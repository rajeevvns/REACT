import React from 'react'
import Text from './Text';

export default {
    title: 'atoms/Text',
    component: Text,
    tags: ['autodocs'],
    decorators: [
        (Story) => (
            <div style={{display: 'flex', justifyContent: 'center', flexWrap: 'wrap'}}>
                {/* 👇 Decorators in Storybook also accept a function. Replace <Story/> with Story() to enable it  */}
                <Story />
            </div>
        ),
    ],
}

function Template(args) {
    return <Text {...args} />
}

const data = {
    label: 'React using Webpack',
    type: 'subtitle'
}
const headingdata = {
    label: 'React',
    type: 'heading'
}
export const Heading = Template.bind({})
Heading.args = {
    ...headingdata,
}

export const SubTitle = Template.bind({})
SubTitle.args = {
    ...data,
}