import React from 'react'
import PropTypes from 'prop-types';

function Text({ label, type = 'heading' }) {
    if (type === 'subtitle') {
        return <p>{label}</p>
    }
    return (
        <h1>{label}</h1>
    )
}

Text.propTypes = {
   /**
   * What is the text Label?
   */
    label: PropTypes.string.isRequired,
   /**
   * Is the Text an heading or subtitle
   */
    type: PropTypes.oneOf(['heading','subtitle'])
}
export default Text