import React from 'react'
import Card from './Card';

export default {
    title: 'molecules/Card',
    component: Card,
}

function Template(args) {
    return <Card {...args} />
}

const data = {
    image: 'https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg',
    title: "Mens Casual Premium Slim Fit T-Shirts",
    btnText: "Buy"
}

export const CardComponent = Template.bind({})
CardComponent.args = {
    ...data,
}