import React from 'react'
import { Button } from '../../atoms/Button/Button'
import Text from '../../atoms/Text/Text'
import './Card.css'

function Card({ image, title, btnText = "Add to Cart" }) {
    return (
        <div className='card'>
            <img src={image} className='card_img_top' />
            <Text label={title} type="subtitle" />
            <Button primary size="small" label={btnText} />
        </div>
    )
}

export default Card